import time
import random
import csv
import traceback
from dateutil import parser
import pandas as pd
from fake_useragent import UserAgent
from datetime import datetime
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class ScrapingInsta():

    def _scroll_human(self):
        """
        Simula scroll humano en la página de perfil.
        """
        body = self.driver.find_element(By.TAG_NAME, "body")
        for _ in range(random.randint(3, 6)):
            body.send_keys(Keys.PAGE_DOWN)
            self._human_delay(1.5, 3.0)
    
    def _extract_text(self, xpath):
        """ Extrae texto de un elemento si está presente. """
        try:
            element = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, xpath))
            )
            return element.text if element else "No disponible"
        except:
            return "No disponible"
    
    def _close_post(self):
        """ Cierra el post actual. """
        try:
            close_btn = WebDriverWait(self.driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//div[@role='dialog']//button"))
            )
            close_btn.click()
            self._human_delay(2, 4)
        except:
            print("⚠️ No se pudo cerrar el post.")
    
    def save_to_csv(self, data, filename):
        """
        Guarda los datos extraídos en un archivo CSV.
        """
        if not data:
            print("No hay datos para guardar en CSV.")
            return
        keys = data[0].keys()
        with open(filename, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=keys)
            writer.writeheader()
            writer.writerows(data)
        print(f"[INFO] Se guardaron {len(data)} filas en {filename}.")

    def save_to_dataframe(self, data, filename="instagram.csv"):
        """ Guarda los datos en un DataFrame, muestra `.head()` y los exporta a CSV. """
        if not data:
            print("⚠️ No hay datos extraídos.")
            return None

        df = pd.DataFrame(data)
        
        # Mostrar las primeras filas del DataFrame
        print("\n📊 **Vista previa de los datos extraídos:**")
        print(df.head())  
        
        # Guardar a CSV
        df.to_csv(filename, index=False, encoding="utf-8")
        print(f"✅ Datos guardados en {filename}")

        return df
    def _close_popups(self):
        """ Cierra cualquier popup emergente que bloquee los clics en la página. """
        try:
            popups = self.driver.find_elements(By.XPATH, "//button[contains(text(), 'Ahora no')] | //div[@role='dialog']//button[contains(text(), 'Cerrar')]")
            for popup in popups:
                self.driver.execute_script("arguments[0].click();", popup)
                self._human_delay(2, 3)
            print("✅ Popups cerrados correctamente.")
        except Exception as e:
            print("⚠️ No se detectaron popups para cerrar.")
    
    def _click_with_scroll(self, element):
        """ Hace scroll al elemento y verifica que sea clickeable antes de hacer clic. """
        try:
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
            self._human_delay(1, 2)  # Esperar estabilización del scroll
            
            # Esperar que sea clickeable
            WebDriverWait(self.driver, 5).until(EC.element_to_be_clickable(element))

            # Click usando JavaScript para evitar overlays
            self.driver.execute_script("arguments[0].click();", element)
            self._human_delay(2, 4)
            return True
        except Exception as e:
            print(f"❌ Error haciendo clic en el elemento: {e}")
            return False